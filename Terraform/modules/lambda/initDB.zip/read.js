////// CHECK ALL USERS ///////////////////

// Require mysql module
const mysql = require('mysql');

// Environment variables should be configured in the Lambda function's settings
const dbConfig = {
    host: process.env.host,
    user: process.env.user,
    password: process.env.password,
    database: 'eduapp' // Directly specifying the database to use
};

// Create a new database connection
const connection = mysql.createConnection(dbConfig);

exports.handler = async (event) => {
  return new Promise((resolve, reject) => {
    // Connect to the database
    connection.connect(err => {
      if (err) {
        console.error('Database connection failed:', err.stack);
        return reject(err);
      }
      console.log('Connected to database.');

      // Execute the query
      connection.query('SELECT * FROM Files', (error, results) => {
        // Close the database connection
        connection.end();

        if (error) {
          console.error('Query execution failed:', error);
          return reject(error);
        }

        console.log('Query execution succeeded. Results:', results);
        resolve({
          statusCode: 200,
          body: JSON.stringify(results)
        });
      });
    });
  });
};