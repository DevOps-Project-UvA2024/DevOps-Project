/////////  INSERT DUMMY ENTRIES /////////

const mysql = require('mysql');

// Environment variables to store RDS connection details
const connectionConfig = {
  host: process.env.host,
  user: process.env.user,
  password: process.env.password,
  // Ensure the database is specified if required for queries that don't explicitly USE a database
};

exports.handler = async (event) => {
  const connection = mysql.createConnection(connectionConfig);

  // List of SQL statements to be executed in order
  const sqlStatements = [
    `USE eduapp`,
    
    `INSERT INTO Users (username, email, role_id) VALUES ('admin', 'admin@eduapp.com', 2);`,
    `INSERT INTO Users (username, email, role_id) VALUES ('PhantomDuck', 'user2@eduapp.com', 1);`,
    `INSERT INTO Users (username, email, role_id) VALUES ('maxairi', 'user3@eduapp.com', 1);`,
    `INSERT INTO Users (username, email, role_id) VALUES ('WannabeEngineer', 'user4@eduapp.com', 1);`,
    `INSERT INTO Users (username, email, role_id) VALUES ('IsThatHim?', 'user5@eduapp.com', 1);`,
    `INSERT INTO Users (username, email, role_id) VALUES ('marianaaaaaa', 'user6@eduapp.com', 1);`,
    `INSERT INTO Users (username, email, role_id) VALUES ('aspa', 'user7@eduapp.com', 1);`,
    `INSERT INTO Users (username, email, role_id) VALUES ('kwtsos', 'user8@eduapp.com', 1);`,
    `INSERT INTO Users (username, email, role_id) VALUES ('jim', 'user9@eduapp.com', 1);`,
    
    `INSERT INTO Courses (name, description, department) VALUES ('DevOps', 'Dive deep into DevOps.', 'Software Engineering');`,
    `INSERT INTO Courses (name, description, department) VALUES ('Modern Business Strategies', 'Explore modern strategies for todays business world.', 'Business');`,
    
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file1.pdf', NOW(), TRUE, 3, 4);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file2.pdf', '2021-03-24 10:15:00', TRUE, 3, 4);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file3.pdf', '2021-03-25 12:20:00', TRUE, 3, 4);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file4.pdf', '2023-03-15 12:40:00', TRUE, 3, 7);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file5.pdf', '2022-09-25 12:55:12', TRUE, 3, 8);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file6.pdf', '2024-03-01 15:20:00', TRUE, 3, 6);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file7.pdf', '2019-03-15 09:21:12', TRUE, 3, 6);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file8.pdf', '2023-12-25 19:23:32', TRUE, 3, 11);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file9.pdf', '2023-12-22 18:23:32', TRUE, 3, 12);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file10.pdf', '2023-12-25 19:32:32', TRUE, 3, 11);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file11.pdf', '2024-03-18 03:21:11', TRUE, 3, 13);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file12.pdf', NOW(), TRUE, 3, 13);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file13.pdf', NOW(), TRUE, 3, 10);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file14.pdf', NOW(), TRUE, 4, 9);`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('/dummyfiles/file15.pdf', NOW(), TRUE, 4, 9);`,
    

    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 5, 2);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.0, 5, 3);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (1.5, 5, 6);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.5, 5, 8);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.0, 5, 11);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 5, 13);`,
    

    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.0, 6, 2);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.5, 6, 3);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 6, 6);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 6, 9);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 6, 10);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 6, 11);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 6, 13);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 6, 12);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 6, 8);`,
    
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 9, 2);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.0, 9, 3);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.5, 9, 4);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (1.5, 9, 6);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.5, 9, 7);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.0, 9, 8);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 9, 10);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 9, 11);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.5, 9, 12);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.0, 9, 13);`,
    
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.5, 7, 2);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 7, 3);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (1.5, 7, 4);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.0, 7, 6);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.0, 7, 8);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.5, 7, 9);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.0, 7, 10);`,
    
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 8, 2);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.0, 8, 3);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.0, 8, 4);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (1.5, 8, 6);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.5, 8, 7);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.5, 8, 9);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 8, 10);`,
    
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.5, 16, 2);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.0, 16, 3);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (1.5, 16, 4);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.0, 16, 6);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 16, 7);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.0, 16, 8);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 16, 9);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.5, 16, 11);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 16, 12);`,
    
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 17, 2);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.0, 17, 3);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.5, 17, 4);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 17, 6);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (1.5, 17, 7);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.0, 17, 8);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.5, 17, 9);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.0, 17, 11);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5.0, 17, 12);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.0, 17, 13);`,
    
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.0, 12, 2);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (2.5, 12, 3);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (1.5, 12, 4);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (4.5, 12, 6);`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (3.5, 12, 7);`
  ];

  const executeQuery = (query) => {
    return new Promise((resolve, reject) => {
      connection.query(query, (error, results) => {
        if (error) {
          console.error('Failed to execute query:', error);
          reject(error);
        } else {
          resolve(results);
        }
      });
    });
  };

  try {
    connection.connect();
    
    for (const query of sqlStatements) {
      await executeQuery(query);
    }

    console.log('All queries executed successfully');
    connection.end();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "All queries executed successfully" }),
    };
  } catch (error) {
    console.error('An error occurred:', error);
    connection.end();
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to execute queries" }),
    };
  }
};
