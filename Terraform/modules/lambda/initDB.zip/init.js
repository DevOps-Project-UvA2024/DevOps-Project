const mysql = require('mysql');

// Environment variables to store RDS connection details
const connectionConfig = {
  host: process.env.host,
  user: process.env.user,
  password: process.env.password,
  // Ensure the database is specified if required for queries that don't explicitly USE a database
};

exports.handler = async (event) => {
  const connection = mysql.createConnection(connectionConfig);

  // List of SQL statements to be executed in order
  const sqlStatements = [
    `DROP SCHEMA IF EXISTS eduapp`,
    `CREATE SCHEMA IF NOT EXISTS eduapp`,
    `USE eduapp`,
    `CREATE TABLE IF NOT EXISTS Roles (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS Users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255) NOT NULL, email VARCHAR(255) UNIQUE NOT NULL, role_id INT NOT NULL, FOREIGN KEY (role_id) REFERENCES Roles(id))`,
    `CREATE TABLE IF NOT EXISTS Courses (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) UNIQUE NOT NULL, description TEXT, department VARCHAR(255) NOT NULL)`,
    `CREATE TABLE IF NOT EXISTS Files (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, upload_date DATETIME NOT NULL, active BOOLEAN NOT NULL DEFAULT TRUE, course_id INT NOT NULL, uploader_id INT NOT NULL, FOREIGN KEY (course_id) REFERENCES Courses(id), FOREIGN KEY (uploader_id) REFERENCES Users(id))`,
    `CREATE TABLE IF NOT EXISTS Votings (id INT AUTO_INCREMENT PRIMARY KEY, voting INT NOT NULL CHECK (voting >= 0 AND voting <= 5), file_id INT NOT NULL, student_id INT NOT NULL, FOREIGN KEY (file_id) REFERENCES Files(id), FOREIGN KEY (student_id) REFERENCES Users(id))`,
    `CREATE TABLE IF NOT EXISTS Subscriptions (id INT AUTO_INCREMENT PRIMARY KEY, student_id INT NOT NULL, course_id INT NOT NULL, active BOOLEAN NOT NULL DEFAULT TRUE, FOREIGN KEY (student_id) REFERENCES Users(id), FOREIGN KEY (course_id) REFERENCES Courses(id))`,
    
    `INSERT INTO Roles (name) VALUES ('Student'), ('Admin')`,
    `INSERT INTO Users (username, email, role_id) VALUES ('kostas', 'konstantinosalouk@gmail.com', 2), ('student1', 'student1@eduapp.com', 1), ('test123', 'test123@eduapp.com',1),('test321', 'test321@eduapp.com',1)`,
    `INSERT INTO Courses (name, description, department) VALUES ('Introduction to Programming', 'Learn the basics of programming.', 'Computer Science'), ('Principles of Management', 'Understanding management principles.', 'Business')`,
    `INSERT INTO Files (name, upload_date, active, course_id, uploader_id) VALUES ('mcaskickconditions.jpg', NOW(), TRUE, 1, 1), ('Management 101.pdf', NOW(), TRUE, 2, 2)`,
    `INSERT INTO Votings (voting, file_id, student_id) VALUES (5, 1, 1), (4, 2, 1)`,
    `INSERT INTO Subscriptions (student_id, course_id, active) VALUES (2, 1, TRUE), (2, 2, FALSE)`
    ];
    
      const executeQuery = (query) => {
    return new Promise((resolve, reject) => {
      connection.query(query, (error, results) => {
        if (error) {
          console.error('Failed to execute query:', error);
          reject(error);
        } else {
          resolve(results);
        }
      });
    });
  };

  try {
    connection.connect();
    
    for (const query of sqlStatements) {
      await executeQuery(query);
    }

    console.log('All queries executed successfully');
    connection.end();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "All queries executed successfully" }),
    };
  } catch (error) {
    console.error('An error occurred:', error);
    connection.end();
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to execute queries" }),
    };
  }
};